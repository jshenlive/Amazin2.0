// CLASS: Company
//
// Author: Jesse Shen, 7909192
//
// REMARKS: Abstract class for Order, Event, Subclass Events
//
//-----------------------------------------

#include "Company.h"

Company::Company() {}
